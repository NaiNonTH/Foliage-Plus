= CHANGELOG: FOLIAGE+ FASTER BUSHY LEAVES V1.2 =

[ALL]

Changed (~)
  ~ Changed Pack format into 9 (Supports 1.14 - 1.19)
  ~ Included license info into Readme.txt
  ~ Changed Creator name from NaiNonTH into NaiNonTheN00b1

[BIOMES O' PLENTY]

Added (+)
  + Added Support for Leaves with Overlayed